const CompanyArr = {
    cf:{
        requestUrl:'https://park.cfeng.wang',
        title:'才风智慧岗亭端',
        name:'caifeng'
    },
    sf:{
        requestUrl:'https://park.ykzncar.cn',
        title:'亦锴智慧岗亭端',
        name:'yikai'
    },
    yg:{
        requestUrl:'http://ygpark.yungoutec.com',
        title:'云狗智慧岗亭端',
        name:'yungou'
    },
    fk:{
        requestUrl:'https://newpark.fksg.net',
        title:'富康智慧岗亭端',
        name:'fukang'
    },
    dw:{
        requestUrl:'https://park.7dewei.com',
        title:'得位停车',
        name:'dewei'
    },
    sixiang:{
        requestUrl:'https://zhtc.foelep.com',
        title:'云上数字集团智慧车场岗亭端',
        name:'sixiang'
    }
}

module.exports =  CompanyArr.sixiang
