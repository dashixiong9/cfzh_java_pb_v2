// 请求域名 h5登录跳转域名
export const baseUrl = 'http://fk.cfeng.wang'

// 首页标题
// export const mpName = '广华智慧停车'
export const mpName = '富康城商业停车场'

// 充电首页标题
// export const mpName2 = '广华智慧充电'
export const mpName2 = '富康商业智慧充电'


// 支付宝小程序appid
export const aliAppid = '2021004133646097'

// 腾讯防水墙appid
export const captchaAppid = '2058476816'

// 微信小程序appid
export const wxAppid = 'wxa3d463778e462355' //
